def get_closest_ship(ship, enemy=False):
    return ship.nearby_entities_by_distance()

