def order_planets(ship, planets):
    output = []
    for planet in planets:
        output.append([planet, ship.calculate_distance_between(planet)])

    def takeSecond(elem):
        return elem[1]

    return [planet[0] for planet in sorted(output, key=takeSecond)]
