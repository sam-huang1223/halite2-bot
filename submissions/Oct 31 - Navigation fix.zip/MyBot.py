"""
This bot's name is Settler. It's purpose is simple (don't expect it to win complex games :) ):
1. Initialize game
2. If a ship is not docked and there are unowned planets
2.a. Try to Dock in the planet if close enough
2.b If not, go towards the planet

Note: Please do not place print statements here as they are used to communicate with the Halite engine. If you need
to log anything use the logging module.
"""

import hlt
from logging import basicConfig, info, DEBUG
from os.path import isfile
from os import remove
from time import clock

class Halite2:
    def __init__(self):
        if isfile('./game_output.log'):
            remove('./game_output.log')
        basicConfig(filename='game_output.log', filemode='a', level=DEBUG)

        self.game = hlt.Game("Zerg")
        # print our start message to the logs
        info("Zerg infestation begins")

        while True:
            self.turn()

    def turn(self):
        startTime = clock()
        self.game_map = self.game.update_map()
        self.command_queue = []
        self.command_tracker = {}
        self.docked_tracker = {planet: len(planet.all_docked_ships()) for planet in self.game_map.all_planets()}

        for ship in self.game_map.get_me().all_ships():
            if ship.docking_status != ship.DockingStatus.UNDOCKED:
                continue

            ordered_planets = self.order_planets(ship=ship, planets=self.game_map.all_planets())
            ##### note all improvements over starter bot
            ### TODO key problems: 1) timeout, 2) collisions
            # TODO REWRITE navigate function to avoid timeouts
            # TODO NOW avoid collisions at all costs (stay if next move causes crash)
            # TODO collide with enemy if health is lower
            # TODO defend docked/docking ships
            # TODO monitor time and detect timeout scenarios
            # TODO track power of players and prioritize targeting weaker players/weaker areas (be 2/3 not 4th)
            # TODO (option 1) weighting of weakest/closest planet to be targeted first
            ##### TODO KEY(option 1) advanced 1v1 attack maneuvers - do 1v1 instead of 1v2 (https://halite.io/learn-programming-challenge/basic-game-rules/game-rules-deep-dive)
            # TODO (ERROR) why do ships crash in (option 1) when attacking docking/docked enemy ships? (see replay above)

            ## TODO new option 4??): If destroying enemy ships requires more resources than destroying planet, navigate around ships to destroy planets instead
            # TODO: HALITE: maximize mining on all owned planets BEFORE exploring (in 1vx, explore > exploit on 1v1) - less vulnerable
            # TODO: (option 2/3): ship should not head towards planet with 2 docking spot if two other ships are already headed towards it (look back in command queue to identify inefficiencies)
            # TODO: to address timeout issue -> keep track of time and send commands if almost timeout
            # TODO (option 1): target docking ships over docked ships
            # TODO (option 1): target planets with minimal ships rather than more ships (easier to take over)
            # TODO (option 1): if enemy nearby, set nearby ships to defend nearby planets

            decision = self.decision(ship, ordered_planets)
            self.command_queue.append(decision['command'])
            self.command_tracker[ship.id] = {'target_planet': decision['target_planet'], 'action': decision['action']}
            timeCheck = clock()
            if timeCheck - startTime > 1.85:
                break
        self.game.send_command_queue(self.command_queue)

    def decision(self, ship, ordered_planets):
        # TODO execute this loop only on nearby planets??
        command = target_planet = action = None
        for planet in ordered_planets:
            if planet.is_owned() and planet.owner != self.game_map.get_me():
                action = 'attack'
                info(action)
                target = planet.all_docked_ships()[0]
                distance_between = max(0, ship.calculate_distance_between(target) - hlt.constants.WEAPON_RADIUS + 1)
                speed = hlt.constants.MAX_SPEED if distance_between > hlt.constants.MAX_SPEED else distance_between
                command = ship.navigate(target, self.game_map, speed=speed, max_corrections=5,
                                        angular_step=5, ignore_ships=False, ignore_planets=False)
                target_planet = planet
                break

            # If we can dock, let's (try to) dock. If two ships try to dock at once, neither will be able to.
            elif ship.can_dock(planet) and not planet.is_full():  # can_dock only checks distance not capacity, use is_full to check capacity
                action = 'mine'
                info(action)
                command = ship.dock(planet)
                target_planet = planet
                break

            elif (not planet.is_owned() or (planet.owner == self.game_map.get_me())
                and not planet.is_full()) and self.check_commands(self.command_tracker, planet, self.docked_tracker):
                # check commands_tracker to see which planets other ships are heading to
                action = 'travel'
                info(action)
                # If we can't dock, we move towards the closest empty point near this planet (by using closest_point_to)
                # with constant speed. Don't worry about pathfinding for now, as the command will do it for you.
                # We run this navigate command each turn until we arrive to get the latest move.
                # Here we move at half our maximum speed to better control the ships
                # In order to execute faster we also choose to ignore ship collision calculations during navigation.
                # This will mean that you have a higher probability of crashing into ships, but it also means you will
                # make move decisions much quicker. As your skill progresses and your moves turn more optimal you may
                # wish to turn that option off.
                command = ship.navigate(ship.closest_point_to(planet), self.game_map,
                                        speed=hlt.constants.MAX_SPEED, max_corrections=5, angular_step=5,
                                        ignore_ships=False, ignore_planets=False)
                target_planet = planet
                break

                # If the move is possible, add it to the command_queue (if there are too many obstacles on the way
                # or we are trapped (or we reached our destination!), navigate_command will return null;
                # don't fret though, we can run the command again the next turn)
        if command is None:
            command = ship.thrust(magnitude=0, angle=0)
        return {'command': command, 'target_planet': target_planet, 'action': action}

    def check_commands(self, commands, planet, docked_tracker):
        count = 0
        for command in commands.values():
            if command['action'] != 'attack' and command['target_planet'] == planet:
                count += 1
        return (count + docked_tracker[planet]) < planet.num_docking_spots

    def order_planets(self, ship, planets):
        output = []
        for planet in planets:
            output.append([planet, ship.calculate_distance_between(planet)])

        def takeSecond(elem):
            return elem[1]

        return [planet[0] for planet in sorted(output, key=takeSecond)]

Halite2()

